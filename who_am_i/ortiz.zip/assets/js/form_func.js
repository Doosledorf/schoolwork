//GENERATE FINAL FORM + CHOICES
function generate_FinalForm( winningChar ){
    
    var comment = wardrobe[winningChar].comment;
    
    